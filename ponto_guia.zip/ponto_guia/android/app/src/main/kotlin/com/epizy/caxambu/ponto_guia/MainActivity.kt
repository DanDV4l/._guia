package com.epizy.caxambu.ponto_guia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
